/***************************************************************
* file: Main.java
* author: 
* class: CS 445 – Computer Graphics
*
* assignment: 
* date last modified: 
*
* purpose: 
*
****************************************************************/ 
package org.cs445.project;

public class Main {

    // method: main
    // purpose: 
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
